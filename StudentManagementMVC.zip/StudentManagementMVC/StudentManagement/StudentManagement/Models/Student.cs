﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagement.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string StudentName { get; set; }
        public string StudentDepartment { get; set; }
        public int StudentMarks { get; set; }
        public string Grade { get; set; }
    }
}
