﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Collections;
using StudentManagement.Models;
using System.IO;
using System.Data.SqlClient;
using System.Data;

namespace StudentManagement.Controllers
{
    public class StudentController : Controller
    {
        // GET: StudentController
        public ActionResult StudentList()
        {
            {
                var StudentList = new List<Student>();
                var dbconfig = new ConfigurationBuilder()
                     .SetBasePath(Directory.GetCurrentDirectory())
                     .AddJsonFile("appsettings.json").Build();
                try
                {
                    var dbconnectionStr = dbconfig["ConnectionStrings:DefaultConnection"];
                    string sql = "SP_Get_StudentList";
                    using (SqlConnection connection = new SqlConnection(dbconnectionStr))
                    {
                        SqlCommand command = new SqlCommand(sql, connection);
                        connection.Open();
                        using (SqlDataReader dataReader = command.ExecuteReader())
                        {
                            while (dataReader.Read())
                            {
                                Student student = new Student();
                                student.Id = Convert.ToInt32(dataReader["Id"]);
                                student.StudentName = Convert.ToString(dataReader["StudentName"]);
                                student.StudentDepartment = Convert.ToString(dataReader["StudentDepartment"]);
                                student.StudentMarks = Convert.ToInt32(dataReader["StudentMarks"]);
                                student.Grade = Convert.ToString(dataReader["Grade"]);
                                StudentList.Add(student);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return View(StudentList);
            }
        }

        // GET: StudentController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        public IActionResult StudentCreate()
        {
            return View();
        }
        [HttpPost]
        public IActionResult StudentCreate(Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var dbconfig = new ConfigurationBuilder()
                   .SetBasePath(Directory.GetCurrentDirectory())
                   .AddJsonFile("appsettings.json").Build();
                    if (!string.IsNullOrEmpty(dbconfig.ToString()))
                    {
                        var dbconnectionStr = dbconfig["ConnectionStrings:DefaultConnection"];
                        using (SqlConnection connection = new SqlConnection(dbconnectionStr))
                        {
                            string sql = "SP_Add_New_Student";
                            using (SqlCommand cmd = new SqlCommand(sql, connection))
                            {
                                cmd.CommandType = CommandType.StoredProcedure; 
                                cmd.Parameters.AddWithValue("@StudentName", student.StudentName);
                                cmd.Parameters.AddWithValue("@StudentDepartment", student.StudentDepartment);
                                cmd.Parameters.AddWithValue("@StudentMarks", student.StudentMarks);
                                cmd.Parameters.AddWithValue("@Grade", student.Grade);
                                connection.Open();
                                cmd.ExecuteNonQuery();
                                connection.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return RedirectToAction("StudentList");
        }
        public IActionResult StudentUpdate(int id)
        {
            var dbconfig = new ConfigurationBuilder()
                  .SetBasePath(Directory.GetCurrentDirectory())
                  .AddJsonFile("appsettings.json").Build();
            var dbconnectionStr = dbconfig["ConnectionStrings:DefaultConnection"];
            var student = new Student();
            using (SqlConnection connection = new SqlConnection(dbconnectionStr))
            {
                string sql = "SP_Get_Student_By_Id";
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", id);
                    connection.Open();
                    using (SqlDataReader dataReader = cmd.ExecuteReader())
                    {
                        while (dataReader.Read())
                        {
                            student.Id = Convert.ToInt32(dataReader["Id"]);
                            student.StudentName = Convert.ToString(dataReader["StudentName"]);
                            student.StudentDepartment = Convert.ToString(dataReader["StudentDepartment"]);
                            student.StudentMarks = Convert.ToInt32(dataReader["StudentMarks"]);
                            student.Grade = Convert.ToString(dataReader["Grade"]);
                        }
                    }
                }
                connection.Close();
            }
            return View(student);
        }
        [HttpPost]
        public IActionResult StudentUpdate(Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var dbconfig = new ConfigurationBuilder()
                   .SetBasePath(Directory.GetCurrentDirectory())
                   .AddJsonFile("appsettings.json").Build();
                    if (!string.IsNullOrEmpty(dbconfig.ToString()))
                    {
                        var dbconnectionStr = dbconfig["ConnectionStrings:DefaultConnection"];
                        using (SqlConnection connection = new SqlConnection(dbconnectionStr))
                        {
                            string sql = "SP_Update_Student";
                            using (SqlCommand cmd = new SqlCommand(sql, connection))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@id", student.Id);
                                cmd.Parameters.AddWithValue("@StudentName", student.StudentName);
                                cmd.Parameters.AddWithValue("@StudentDepartment", student.StudentDepartment);
                                cmd.Parameters.AddWithValue("@StudentMarks", student.StudentMarks);
                                cmd.Parameters.AddWithValue("@Grade", student.Grade);
                                connection.Open();
                                cmd.ExecuteNonQuery();
                                connection.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return RedirectToAction("StudentList");
        }

        [HttpPost]
        public IActionResult StudentDelete(int id)
        {
            var dbconfig = new ConfigurationBuilder()
                  .SetBasePath(Directory.GetCurrentDirectory())
                  .AddJsonFile("appsettings.json").Build();
            var dbconnectionStr = dbconfig["ConnectionStrings:DefaultConnection"];
            using (SqlConnection connection = new SqlConnection(dbconnectionStr))
            {
                string sql = "SP_Delete_Student_By_Id";
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", id);
                    connection.Open();
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (SqlException ex)
                    {

                    }
                    connection.Close();
                }
            }
            return RedirectToAction("StudentList");
        }

    }
}
